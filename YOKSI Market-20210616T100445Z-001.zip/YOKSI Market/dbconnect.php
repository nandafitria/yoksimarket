<?php 
// isi nama host, username mysql, dan password mysql anda
$conn = mysqli_connect("localhost","root","","Yoksi Market");

if(!$conn){
	echo "gagal konek database menn";
} else {
	
};

?>